<?php
    echo "Appoinment Number: ".$_GET['AppointmentN']."<br>";
    echo "Appoinment Date: ".$_GET['AppointmentD']."<br>";
    echo "Appoinment Time: ".$_GET['AppointmentT']."<br>";
    echo "Doctor Name: ".$_GET['DoctorN']."<br>";
?>